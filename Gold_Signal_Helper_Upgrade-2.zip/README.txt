# Gold Signal Helper — GitHub Pages upgrade

## Files
- `index.html`: responsive dashboard, manual technical inputs, rule-based WAIT/BUY/SELL assessment, risk calculator, optional quote-endpoint client.
- `manifest.json`: installable web app metadata.
- `sw.js`: basic offline shell cache.

## Publish from GitHub mobile
1. Open your repository `gold_signal_helper_android`.
2. Replace the contents of `index.html` with the provided `index.html` file.
3. Create or replace `manifest.json` with the provided manifest.
4. Create `sw.js` in the repository root and paste its contents.
5. Commit all changes to the `main` branch.
6. Open repository Settings → Pages. Set source to deploy from a branch, branch `main`, folder `/(root)`, then save.
7. Wait for the Pages deployment to finish, then open the published URL over HTTPS. Refresh the page. On Android Chrome, use menu ⋮ → Add to Home screen / Install app if available.

## Broker/live-data integration
A static GitHub Pages frontend cannot securely store a broker secret or directly control an MT5 terminal. To use live prices, build or use a trusted backend that authenticates with the broker/API and returns JSON like:
`{"symbol":"XAUUSD","price":1234.56,"timestamp":"2026-01-01T12:00:00Z"}`
The numbers/date above are schema examples only, not a quote. Configure CORS to allow your Pages origin. Do not expose API keys, passwords, account IDs, or trading tokens in HTML or a public repository. Never send live orders from this sample app.

## Important limits
- The technical signal is a simple educational EMA/RSI rule set. It does not prove a trade is profitable and is not a guarantee.
- Risk estimates use `price distance × contract size in ounces per lot × lot size`; broker contract size, lot steps, commissions, spread, slippage, swaps and account currency conversion can change actual P/L.
- The default contract size of 100 oz and minimum lot of 0.01 are examples. Verify these with your broker before use.
- No API credentials, real-time prices, or broker integration are included.
